<?php

namespace Mpdf\Tag;

class S extends InlineTag
{


}
